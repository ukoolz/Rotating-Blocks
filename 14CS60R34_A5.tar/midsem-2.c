#include <stdio.h>
#include <stdlib.h>

int initial[7], final[7], operation[4] = {1,2,3,4}, no_of_ops;

int success = 0;

int stack[1024] = {0}, top = 0;

int* left_to_mid(int *a) {
	int i, temp = a[0], *new = (int *) calloc(7, sizeof(int));
	for (i = 0; i < 7; ++i)
		new[i] = a[i];
	for (i = 1; i < 4; ++i)
		new[i-1] = new[i];
	new[i-1] = temp;
	return new;
}

int* right_to_mid(int *a) {
	int i, temp = a[6], *new = (int *) calloc(7, sizeof(int));
	for (i = 0; i < 7; ++i)
		new[i] = a[i];
	for (i = 6; i > 3; i--)
		new[i] = new[i-1];
	new[i] = temp;
	return new;
}
int* mid_to_left(int *a) {
	int i, temp = a[3], *new = (int *) calloc(7, sizeof(int));
	for (i = 0; i < 7; ++i)
		new[i] = a[i];
	for (i = 3; i > 0; i--)
		new[i] = new[i-1];
	new[i] = temp;
	return new;
}
int* mid_to_right(int *a) {
	int i, temp = a[3], *new = (int *) calloc(7, sizeof(int));
	for (i = 0; i < 7; ++i)
		new[i] = a[i];
	for (i = 4; i < 7; ++i)
		new[i-1] = new[i];
	new[i-1] = temp;
	return new;
}

int is_same(int a[], int b[]) {
	int i = 0;
	for (i = 0; i < 7; ++i)
		if (a[i] != b[i])
			return 0;
	return 1;
}

void dfs(int a[], int goal[], int level, int depth) {
	if(is_same(a, goal)) {
		success = 1;
		return;
	}
	else if(depth == level)
		return;
	int i, *l_t_m, *r_t_m, *m_t_l, *m_t_r;
	for (i = 0; i < no_of_ops; ++i) {
		switch(operation[i]) {
			case 1:
				l_t_m = left_to_mid(a);
				dfs(l_t_m, goal, level, depth + 1);
				if (success) {
					stack[top++] = 1;
					return;
				}
				break;
			case 2:
				r_t_m = right_to_mid(a);
				dfs(r_t_m, goal, level, depth + 1);
				if (success) {
					stack[top++] = 2;
					return;
				}
				break;
			case 3:
				m_t_l = mid_to_left(a);
				dfs(m_t_l, goal, level, depth + 1);
				if (success) {
					stack[top++] = 3;
					return;
				}
				break;
			case 4:
				m_t_r = mid_to_right(a);
				dfs(m_t_r, goal, level, depth + 1);
				if (success) {
					stack[top++] = 4;
					return;
				}
				break;
		}
	}
	
}

int main(int argc, char const *argv[])
{
	int i;
	for (i = 0; i < 7; ++i) 
		scanf("%d", &initial[i]);
	for (i = 0; i < 7; ++i) 
		scanf("%d", &final[i]);
	no_of_ops = 4;
	


	int level;
	for (level = 0; level < 10; ++level)
		if(!success)
			dfs(initial, final, level, 0);

	printf("Min no of operations = %d\n", top);

	for (i = top-1; i >= 0; --i) {
		switch(stack[i]) {
			case 1:
				printf("LEFT_TO_MID\n");
				break;
			case 2:
				printf("RIGHT_TO_MID\n");
				break;
			case 3:
				printf("MID_TO_LEFT\n");
				break;
			case 4:
				printf("MID_TO_RIGHT\n");
				break;
		}
	}

	return 0;
}