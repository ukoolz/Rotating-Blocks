#include <stdio.h>
#include <stdlib.h>

int initial[7], final[7], operation[10] = {0}, no_of_ops;

int success = 0;

int stack[1024] = {0}, top = 0;

int* left_to_mid(int *a) {
	int i, temp = a[0], *new = (int *) calloc(7, sizeof(int));
	for (i = 0; i < 7; ++i)
		new[i] = a[i];
	for (i = 1; i < 4; ++i)
		new[i-1] = new[i];
	new[i-1] = temp;
	return new;
}

int* right_to_mid(int *a) {
	int i, temp = a[6], *new = (int *) calloc(7, sizeof(int));
	for (i = 0; i < 7; ++i)
		new[i] = a[i];
	for (i = 6; i > 3; i--)
		new[i] = new[i-1];
	new[i] = temp;
	return new;
}
int* mid_to_left(int *a) {
	int i, temp = a[3], *new = (int *) calloc(7, sizeof(int));
	for (i = 0; i < 7; ++i)
		new[i] = a[i];
	for (i = 3; i > 0; i--)
		new[i] = new[i-1];
	new[i] = temp;
	return new;
}
int* mid_to_right(int *a) {
	int i, temp = a[3], *new = (int *) calloc(7, sizeof(int));
	for (i = 0; i < 7; ++i)
		new[i] = a[i];
	for (i = 4; i < 7; ++i)
		new[i-1] = new[i];
	new[i-1] = temp;
	return new;
}

void return_goal(int *a, int *operation) {
	int i, *active = a;
	for (i = 0; i < no_of_ops; ++i) {
		switch(operation[i]) {
			case 1:
				active = left_to_mid(active);
				break;
			case 2:
				active = right_to_mid(active);
				break;
			case 3:
				active = mid_to_left(active);
				break;
			case 4:
				active = mid_to_right(active);
				break;
		}
	}
	printf("Final Conf : ");
	for (i = 0; i < 7; ++i)
		printf("%d ", active[i]);
	printf("\n");
	return;
}

int main(int argc, char const *argv[]) {
	int i;
	for (i = 0; i < 7; ++i) 
		scanf("%d", &initial[i]);
	i = 0;
	while(scanf("%d", &operation[i++]) != EOF);
	no_of_ops = i-1;

	return_goal(initial, operation);

	return 0;
}